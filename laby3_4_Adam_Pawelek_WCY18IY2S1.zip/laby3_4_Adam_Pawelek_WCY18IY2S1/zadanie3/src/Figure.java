public interface Figure {
    public void move(double x, double y);
    public void flip();
    public boolean equals(Object o);
    public String toString();
}
