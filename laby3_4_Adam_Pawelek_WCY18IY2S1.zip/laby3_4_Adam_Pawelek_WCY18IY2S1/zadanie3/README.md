
# **W tym projekcie znajdują się zarówno rozwiązania do zdania 3 jak i do zadania 4.**

W zadaniu 4 zaimplementowałem 2 metody które sortują Punkty
1. Jest mi potrzebana do metody equals dzięki czemu mogę w szybki sposób 
porównać 2 Figury

2. Jest to sorotwanie kątowe dzięki czemu można podawać wierzchołki 
wielokąta wypukłego w dowolnej kolejności. 


Zadanie 4 wyrzuca wyrzuca stworzony przeze mnie wyjątek kiedy liczba 
punktów wielokąta jest mniejsza niż 3.

Wstępne przetestowanie znajduję się w pliku Main.java

Kod potrzebny do zdebagowania zadania 0 znajduje się w pliku 
List.java.