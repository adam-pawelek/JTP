Zadanie 1.c

Ja zadanie 1 a) również wykonałem poprzez rzucanie wyjątku w moim przypadku różni się tylko tym że rzucamy wyjątek Exception w factorial a myException   (jest to rozszerzenie wyjątku Exception) w factorial1.
