public class MyException extends Exception {
    public MyException (String messege){
        super(messege);
    }
}
