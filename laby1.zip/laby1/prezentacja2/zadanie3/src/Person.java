import java.util.List;
import java.util.Random;

public class Person {
    public String imie;
    public String nazwisko;

    public Person(String imie, String nazwisko){
        this.imie = imie;
        this.nazwisko = nazwisko;
    }
    public Person(){

    }
}
