import org.junit.Assert;
import org.junit.Test;
import static org.junit.Assert.*;

public class PointTest {

    /*
    @Test
    public Point(int x, int y){
        this.x = x;
        this.y = y;
        Assert.assertEquals(12,12);
    }
*/
    @Test
    public void pomoz(){
        Assert.assertEquals(12,12);
    }
}