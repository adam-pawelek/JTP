Zrobilem wszystkie zadania: 

Zadanie 1 w klasie Flaga

Zadanie 2 (warcaby w klasie Szachy).


W zadaniu z pionakmi wykonałem logikę dzięki której można prouszać się po 
planszy pionkami i bić pionki do przodu.

Należy napierw wybrać pionek klikając na niego a następnie pole na które 
chcemy żeby dany pionek się poruszył, program zabrania wykonywania ruchów nie 
dozwolonych w warcabach.

Jeżeli wybraliśmy jakiś pionek ale chcemy poruszyć się innym, to musimy
nacisnąć żółty kwadrat znajdującu się w prwaym dolnym rogu.

